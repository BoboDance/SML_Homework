import numpy as np
import pandas as pd

c1_points = pd.read_csv('densEst1.txt', sep="  ", header=None)
c2_points = pd.read_csv('densEst1.txt', sep="  ", header=None)
c1_points.columns = c2_points.columns = ["x1", "x2"]

c1_mean = np.empty((c1_points.shape[1]))
c2_mean = np.empty((c1_points.shape[1]))
c1_covariance = np.empty((c1_points.shape[1]))
c2_covariance = np.empty((c1_points.shape[1]))

